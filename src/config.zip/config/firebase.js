/** @format */

import { initializeApp } from 'firebase/app';
import { getAnalytics } from 'firebase/analytics';
import { getFirestore } from 'firebase/firestore';
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: 'AIzaSyC88jIykY2Wj2RYEYubkQq1dge74x-nJOs',
  authDomain: 'react-firestore-nz.firebaseapp.com',
  projectId: 'react-firestore-nz',
  storageBucket: 'react-firestore-nz.appspot.com',
  messagingSenderId: '923472955482',
  appId: '1:923472955482:web:6af4a7fd854dcf96ebf063',
  measurementId: 'G-ZRL0N4D6YL',
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

export default db;
